package infrastructure.persistence.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import infrastructure.persistence.IPersistencia;
import models.Usuario;

public class MysqlRepositoryImpl implements IPersistencia {

	private Connection conexion;
	
	public MysqlRepositoryImpl() {
		conexion = ConexionBD.getConnection();
	}
	
	
	@Override
	public void guardarUsuario(Usuario newUsuario) {
		String query = "INSERT INTO usuarios (nombre, apellido) VALUES (?,?)"; 
		
		try {
			PreparedStatement statement = conexion.prepareStatement(query);
			
			statement.setString(1, newUsuario.getNombre());
			statement.setString(2, newUsuario.getApellido());
			
			statement.execute();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Usuario getUsuarioById(String idUsuarioBuscado) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Usuario> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Usuario update(Usuario datosParaActualizar) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

}
