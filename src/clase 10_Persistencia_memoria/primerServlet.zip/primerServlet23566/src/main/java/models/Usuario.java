package models;

import java.util.UUID;

public class Usuario {
	
	private static int contador;
	
	private int idUsuario;
	private UUID idUUID;
	private String nombre;
	private String apellido;
	
	public Usuario(String nombre, String apellido) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.idUsuario = ++contador;
		this.idUUID = UUID.randomUUID(); // modo alternativo
	}

	public String getNombre() {
		return nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public int getIdUsuario() {
		return idUsuario;
	}

	public UUID getIdUUID() {
		return idUUID;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	
	
	

}
