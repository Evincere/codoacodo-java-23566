package mappers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import models.Usuario;

public class UsuarioMapper {
	
	ObjectMapper mapper;
	
	public UsuarioMapper() {
		this.mapper = new ObjectMapper();
	}
	
	public String toJson(Usuario usuario) {
		
		try {
			return mapper.writeValueAsString(usuario);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

}
