package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "/endpoint")
public class PrimerServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

   
    public PrimerServlet() {
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
			out.write("<h1>REQUEST CONTESTADA DESDE EL SERVLET<h1>");
			out.write("<p>podria ser un párrafo también<p>");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String nombre = request.getParameter("nombreInput");
		String apellido = request.getParameter("apellidoInput");
		
		System.out.println("nombre de usuario: " + nombre + " " + apellido);
		
		response.getWriter().write("nombre de usuario: " + nombre + " " + apellido +" ha sido dado de alta");
	
//		response.sendRedirect("confirmacion.html");
		
	
	}

}
