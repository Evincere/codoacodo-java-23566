package infrastructure.persistence.files;

import java.util.ArrayList;

import infrastructure.persistence.IPersistencia;
import models.Usuario;

public class FileRepositoryImpl implements IPersistencia {

	@Override
	public void guardarUsuario(Usuario newUsuario) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Usuario getUsuarioById(String idUsuarioBuscado) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Usuario> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Usuario update(Usuario datosParaActualizar) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

}
